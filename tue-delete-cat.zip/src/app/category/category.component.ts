import { Category } from './../model/Category';
import { Component, OnInit } from '@angular/core';

import { Router, Event, NavigationEnd } from '@angular/router';
import { CategoryService } from './../category.service';
import { Status } from '../model/Status';
@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  category:Category
  successFlag: boolean
  errorFlag: boolean
  categorys: Category[]
  progressFlag: boolean
  constructor(public authService: CategoryService, public router: Router) {
    this.initCategory()
    this.categorys=[]
  }

  initCategory() {
    this.category = {
      cid: 0,
      categoryName: ''}}
      

  ngOnInit() {
  }

  categorySubmit(categoryForm) {

    this.successFlag = false
    this.errorFlag = false

    this.authService.addCategory(this.category)
      .subscribe((res: Category) => {
        
        if (res !== null) {
          this.successFlag = true
          this.authService.categoryStatus = true
          this.router.navigateByUrl('/category')
        }
        else {
          this.errorFlag = true
          this.authService.categoryStatus = false
        }
      }, err => {
        console.log(err)
        this.errorFlag = true
        this.authService.categoryStatus = false
      })
      
  }
 
  
  getCategory() {
    this.progressFlag = true
    this.authService.getCategory()
      .subscribe((res: Category[]) => {
        if (res) {
          this.categorys = res
        }

        this.progressFlag = false

      })
  }

  
  deleteCategory(cid, index) {
    this.authService.deleteCategory(cid)
      .subscribe((res: Status) => {
        if (res.queryStatus)
          this.categorys.splice(index, 1)
      })
  }
  
    }
  
