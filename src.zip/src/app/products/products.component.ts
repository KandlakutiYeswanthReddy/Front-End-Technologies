import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product';
import { AuthenticateService } from '../authenticate.service';
import { ProductsService } from '../products.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  newProduct: Product

  constructor(public productsService: ProductsService, public authService: AuthenticateService) {
    this.newProduct= new Product()
  }

  ngOnInit() {  

}

addProduct(addForm) {
  this.productsService.addProduct(this.newProduct)
  .subscribe((data:Product) => {
    this.productsService.products.unshift()
    addForm.form.markAsPristine()
    this.newProduct = new Product()
  })
}
}