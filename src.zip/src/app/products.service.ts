import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Product } from './model/product';

const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  public products: []

  constructor(public http: HttpClient) {
    this.products = []
  }

  getProduct() {
    return this.http.get('http://172.18.218.134:8444/grocery/posts/all', httpOptions)
  }

  addProduct(product: Product) {
    return this.http.post('http://172.18.218.134:8444/grocery/posts/save', product, httpOptions)
  }


  editProduct(product: Product) {
    return this.http.put('http://172.18.218.134:8444/grocery/posts/edit', product, httpOptions)
  }

}