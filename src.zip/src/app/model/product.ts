export class Product {
    pid:number
    pname: string
    price: number
   pqty: number
    unit:string
   

    constructor() {
       this.pid = 0
        this.pname = ''
        this.price = 0
        this.pqty = 0
        this.unit = ''


       
    }
}